ls
cd Documents
ls
cat reading-list.md
cd
clear
history -c
exit
