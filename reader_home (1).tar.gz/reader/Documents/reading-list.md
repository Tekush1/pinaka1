# reading list

- [x] The Linux Command Line
- [x] How Linux Works
- [ ] Linux Basics for Hackers
- [x] ████████████████████  (red letters, a hood on the cover. the free sample was enough to get hooked)
- [ ] finish Part VI
