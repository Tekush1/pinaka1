# ~/.bashrc: executed by bash(1) for non-login shells.
case $- in
    *i*) ;;
      *) return;;
esac

HISTCONTROL=ignoreboth
shopt -s histappend
HISTSIZE=1000
HISTFILESIZE=2000

# keep history out of the obvious place
HISTFILE="$HOME/.local/state/.h"
HISTTIMEFORMAT='%F %T  '

shopt -s checkwinsize
PS1='\u@\h:\w\$ '

alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'

[ -f ~/.motd ] && cat ~/.motd
