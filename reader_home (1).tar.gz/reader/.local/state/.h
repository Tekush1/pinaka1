#1793462462
cd ~
#1793462465
ls -la
#1793462472
mount | grep -i kindle
#1793462490
cp "/media/reader/Kindle/documents/My Clippings.txt" ~/.local/share/.mc
#1793462501
grep -c 'clipping limit' ~/.local/share/.mc
#1793462530
Q=$(rev ~/.../q | base64 -d)
#1793462534
xdg-open "https://www.amazon.in/s?k=${Q// /+}&i=digital-text"
#1793462752
export ASIN=$(cat ~/.cache/.asin)
#1793462770
pick(){ tr -cs "A-Za-z'" '\n' | sed '/^$/d' | sed -n "${1}p" | tr 'A-Z' 'a-z'; }
#1793462791
note(){ grep -o 'w=[0-9]*' ~/.local/share/.mc | sed -n "${1}p" | cut -d= -f2; }
#1793462882
vim /dev/shm/h1 /dev/shm/h2 /dev/shm/h3 /dev/shm/h4
#1793463460
for i in 1 2 3 4; do pick "$(note $i)" < /dev/shm/h$i; done | paste -sd- | tr -d '\n' > /dev/shm/.k
#1793463464
printf -- '-%s' "${ASIN,,}" >> /dev/shm/.k
#1793463481
openssl enc -aes-256-cbc -salt -pbkdf2 -iter 250000 -md sha256 -in ~/flag.txt -out ~/.vault/flag.enc -pass file:/dev/shm/.k
#1793463495
shred -u ~/flag.txt /dev/shm/h1 /dev/shm/h2 /dev/shm/h3 /dev/shm/h4 /dev/shm/.k ~/.cache/.asin
#1793463520
sed -i -E 's/^(\xEF\xBB\xBF)?[^(]+\(K[a-z]+ D[a-z]+\)\r$/\1[REDACTED] (K******* D******)\r/' ~/.local/share/.mc
#1793463532
history -w
