﻿The Art of War (Sun Tzu)
- Your Highlight on Location 112-112 | Added on Friday, 30 October 2026 23:02:11

All warfare is based on deception.
==========
The Art of War (Sun Tzu)
- Your Bookmark on Location 210 | Added on Friday, 30 October 2026 23:05:40


==========
[REDACTED] (K******* D******)
- Your Highlight on Location 47-48 | Added on Saturday, 31 October 2026 21:14:03

<You have reached the clipping limit for this item>
==========
[REDACTED] (K******* D******)
- Your Note on Location 48 | Added on Saturday, 31 October 2026 21:14:41

w=17/19 md5(w)=67
==========
[REDACTED] (K******* D******)
- Your Highlight on Location 104-105 | Added on Saturday, 31 October 2026 21:16:12

<You have reached the clipping limit for this item>
==========
[REDACTED] (K******* D******)
- Your Note on Location 105 | Added on Saturday, 31 October 2026 21:16:50

w=11/15 md5(w)=c6
==========
[REDACTED] (K******* D******)
- Your Highlight on Location 200 | Added on Saturday, 31 October 2026 21:18:27

<You have reached the clipping limit for this item>
==========
[REDACTED] (K******* D******)
- Your Note on Location 200 | Added on Saturday, 31 October 2026 21:18:59

w=2/3 md5(w)=4b
==========
[REDACTED] (K******* D******)
- Your Highlight on Location 292-293 | Added on Saturday, 31 October 2026 21:20:33

<You have reached the clipping limit for this item>
==========
[REDACTED] (K******* D******)
- Your Note on Location 293 | Added on Saturday, 31 October 2026 21:21:08

w=12/12 md5(w)=fc
==========
